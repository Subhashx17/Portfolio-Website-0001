/* PROFILE: replace every <PLACEHOLDER>. Photo: put a file in assets/images/ and set photo: "assets/images/me.jpg" */
window.SITE = window.SITE || {};
SITE.profile = {
  name: "<Name>",
  role: "Student",
  photo: "assets/images/Photo.jpg",
  college: "VIT-AP , Amaravati",
  year: "1st Year / Fresher",
  introduction: "<INTRO>",
  interests: ["Web Development", "Cybersecurity", "Mathematics"],
  contactHeadline: "Contact Me"
};
