/* PROJECTS: one project for now. To add more, copy the object and add it to the list. */
window.SITE = window.SITE || {};
SITE.projects = [
  {
    name: "WIOS Club Website Redesign Prototype",
    description: "",
    image: "assets/images/project1.png",           // e.g. "assets/images/project.jpg" (use "../assets/images/..." from this page's perspective)
    technologies: ["<TECHNOLOGY>", "<TECHNOLOGY>"],
    github: "<PROJECT_GITHUB_URL>",
    live: "<PROJECT_LIVE_URL>"
  }
];
