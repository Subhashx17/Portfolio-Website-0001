(function(){
const S=window.SITE,B=document.body,ROOT=B.dataset.root||'./',PAGE=B.dataset.page;
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches,FILE=location.protocol==='file:';
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const ph=v=>/^<.*>$/.test(v||''),url=v=>ph(v)?'#':v,mail=v=>ph(v)?'#':'mailto:'+v;
const route=p=>ROOT+(p?p+'/':'')+(FILE?'index.html':'');
const get=p=>p.split('.').reduce((o,k)=>o&&o[k],S);
const asset=v=>/^(https?:|data:|\/)/.test(v)?v:ROOT+v;

document.querySelectorAll('[data-bind]').forEach(n=>n.textContent=get(n.dataset.bind));
document.querySelectorAll('[data-chips]').forEach(n=>get(n.dataset.chips).forEach(v=>n.appendChild(el('li',0,v))));
document.title=S.profile.name+' · '+({home:'Home',projects:'Projects','tech-stack':'Tech Stack',contact:'Contact'}[PAGE]);

const pages=[['Home','','home'],['Projects','projects','projects'],['Tech Stack','tech-stack','tech-stack'],['Contact','contact','contact']];
const nav=el('header','nav'),logo=el('a','logo',S.profile.name);logo.href=route('');nav.appendChild(logo);
const ul=el('ul');pages.forEach(([n,p,k])=>{const li=el('li'),a=el('a',0,n);a.href=route(p);if(k===PAGE)a.setAttribute('aria-current','page');li.appendChild(a);ul.appendChild(li)});
const nv=el('nav');nv.setAttribute('aria-label','Main');nv.appendChild(ul);nav.appendChild(nv);B.prepend(nav);
const ft=el('footer','foot');ft.appendChild(el('span',0,'© '+new Date().getFullYear()+' '+S.profile.name));
const fl=el('div');[['Email',mail(S.socials.email)],['GitHub',url(S.socials.github)],['LinkedIn',url(S.socials.linkedin)]].forEach(([n,h])=>{const a=el('a',0,n);a.href=h;fl.appendChild(a)});
ft.appendChild(fl);B.appendChild(ft);
document.querySelectorAll('[data-route]').forEach(a=>a.href=route(a.dataset.route));
addEventListener('scroll',()=>nav.classList.toggle('s',scrollY>30),{passive:true});

const photo=document.getElementById('hPhoto');
if(photo){if(ph(S.profile.photo)){photo.textContent=S.profile.photo}else{const i=new Image();i.src=asset(S.profile.photo);i.alt=S.profile.name;photo.appendChild(i)}}
const soc=document.getElementById('hSoc');
if(soc)[['GitHub',S.socials.github],['LinkedIn',S.socials.linkedin]].forEach(([n,h])=>{const a=el('a','link',n);a.href=url(h);a.target='_blank';a.rel='noopener';soc.appendChild(a)});
const pl=document.getElementById('projList');
if(pl)S.projects.forEach((p,i)=>{
  const a=el('article','proj rv');a.appendChild(el('span','proj-n',String(i+1).padStart(2,'0')+' / '+String(S.projects.length).padStart(2,'0')));
  const b=el('div','proj-b'),im=el('a','proj-img');im.href=url(p.live);im.dataset.cursor='View';im.setAttribute('aria-label',p.name);
  if(ph(p.image)){im.appendChild(el('div',0,p.image))}else{const g=new Image();g.src=asset(p.image);g.alt=p.name;im.appendChild(g)}
  const t=el('div','proj-t');t.appendChild(el('h2',0,p.name));
  const d=el('div');d.appendChild(el('p',0,p.description));
  const tg=el('ul','tags');p.technologies.forEach(x=>tg.appendChild(el('li',0,x)));d.appendChild(tg);
  const l=el('div','links');[['GitHub',p.github],['Live site',p.live]].forEach(([n,h])=>{const k=el('a','link',n);k.href=url(h);k.target='_blank';k.rel='noopener';l.appendChild(k)});
  d.appendChild(l);t.appendChild(d);b.append(im,t);a.appendChild(b);pl.appendChild(a)});
const tl=document.getElementById('techList');
if(tl)S.skills.filter(c=>c.items.length).forEach(c=>{const s=el('section','cat rv');s.appendChild(el('h2','lbl',c.title));const u=el('ul');c.items.forEach(x=>u.appendChild(el('li',0,x)));s.appendChild(u);tl.appendChild(s)});
const cl=document.getElementById('contactList');
if(cl)[['Email',S.socials.email,mail],['GitHub',S.socials.github,url],['LinkedIn',S.socials.linkedin,url],['Discord',S.socials.discord,url]].forEach(([n,v,f])=>{
  const li=el('li'),a=el('a');a.href=f(v);if(n!=='Email'){a.target='_blank';a.rel='noopener'}a.append(el('span',0,n),el('span','lbl',ph(v)?v:'↗'));li.appendChild(a);cl.appendChild(li)});
const cm=document.getElementById('cMail');if(cm){cm.textContent=S.socials.email;cm.href=mail(S.socials.email);cm.dataset.cursor='Write'}

const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('v');io.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.rv').forEach(n=>io.observe(n));

/* page transition: veil slides up, next page slides it away */
const veil=el('div','veil');B.appendChild(veil);
if(!RM){
  if(sessionStorage.getItem('veil')){veil.style.transition='none';veil.style.transform='translateY(0)';sessionStorage.removeItem('veil');
    requestAnimationFrame(()=>requestAnimationFrame(()=>{veil.style.transition='';veil.style.transform='translateY(-100%)'}))}
  document.addEventListener('click',e=>{
    const a=e.target.closest('a[href]');if(!a||e.metaKey||e.ctrlKey||e.shiftKey||a.target==='_blank')return;
    const u=new URL(a.href,location.href);
    if(u.protocol==='mailto:'||a.getAttribute('href')==='#'||u.href===location.href||(!FILE&&u.origin!==location.origin))return;
    e.preventDefault();sessionStorage.setItem('veil','1');veil.style.transform='translateY(0)';setTimeout(()=>{location.href=a.href},420)});
  addEventListener('pageshow',e=>{if(e.persisted)veil.style.transform='translateY(100%)'});
}
/* opening animation: Home, once per session */
if(PAGE==='home'&&!RM&&!sessionStorage.getItem('seen')){
  sessionStorage.setItem('seen','1');
  const i=el('div','intro'),w=el('div');w.appendChild(el('span',0,S.profile.name));i.appendChild(w);B.appendChild(i);
  requestAnimationFrame(()=>requestAnimationFrame(()=>i.classList.add('in')));
  setTimeout(()=>{i.classList.add('out');setTimeout(()=>i.remove(),900)},1300);
}

/* HOME: scroll position drives the composition (reversible) */
const stage=document.getElementById('stage');
const mq=matchMedia('(min-width:821px) and (prefers-reduced-motion:no-preference)');
if(stage&&mq.matches){
  const pin=document.getElementById('pin'),head=document.getElementById('hHead'),role=document.getElementById('hRole'),hint=document.getElementById('hHint');
  const col=[...document.getElementById('hCol').children],root=document.documentElement;
  const cl2=(v,a=0,b=1)=>Math.min(b,Math.max(a,v)),ease=t=>t*t*(3-2*t),seg=(p,a,b)=>ease(cl2((p-a)/(b-a))),lerp=(a,b,t)=>a+(b-a)*t;
  const stops=[[0,[248,244,236]],[.35,[250,229,215]],[.62,[232,224,246]],[.85,[222,235,247]],[1,[221,239,226]]];
  const colorAt=p=>{for(let i=1;i<stops.length;i++)if(p<=stops[i][0]){const[a,ca]=stops[i-1],[b,cb]=stops[i],t=(p-a)/(b-a);return ca.map((v,k)=>Math.round(lerp(v,cb[k],t)))}return stops[4][1]};
  let W,H,nl,nt,hh,ticking=false;
  const measure=()=>{W=innerWidth;H=pin.offsetHeight;photo.style.transform='none';head.style.transform='none';nl=photo.offsetLeft;nt=photo.offsetTop;hh=head.offsetHeight;frame()};
  function frame(){ticking=false;
    const r=stage.getBoundingClientRect(),p=cl2(-r.top/(stage.offsetHeight-H));
    const a=seg(p,.1,.4),y1=H*.12;
    head.style.transform=`translate(0,${lerp(H*.5,y1,a)}px) scale(${lerp(1,.4,a)})`;
    role.style.opacity=1-seg(p,.08,.22);
    const b=seg(p,.14,.46);
    photo.style.transform=`translate(${lerp(0,W*.05-nl,b)}px,${lerp(0,y1+hh*.4+28-nt,b)}px) scale(${lerp(1,.62,b)})`;
    [[.3,.44],[.44,.58],[.58,.7],[.76,.88]].forEach(([s,e],i)=>{const o=seg(p,s,e),n=col[i];n.style.opacity=o;n.style.transform=`translateY(${(1-o)*16}px)`;n.style.pointerEvents=o>.6?'auto':'none'});
    hint.style.opacity=1-seg(p,0,.06);
    root.style.setProperty('--bg','rgb('+colorAt(p).join(',')+')')}
  const req=()=>{if(!ticking){ticking=true;requestAnimationFrame(frame)}};
  addEventListener('scroll',req,{passive:true});addEventListener('resize',measure);
  if(document.fonts)document.fonts.ready.then(measure);measure();
  mq.addEventListener('change',()=>location.reload());
}



/* =========================================
   GLOWING LIGHT TRAIL CURSOR
   ========================================= */

if (
  matchMedia('(hover:hover) and (pointer:fine)').matches &&
  !RM
) {

  B.classList.add('has-cursor');

  /*
   * Create the canvas.
   */
  const canvas = document.createElement('canvas');

  canvas.className = 'cursor-glow';

  document.body.appendChild(canvas);

  const ctx = canvas.getContext('2d');

  /*
   * Optional cursor label.
   */
  const c = el('div', 'cur');
  const l = el('div', 'cur-l');

  B.append(c, l);


  /* -----------------------------------------
     CANVAS SIZE
     ----------------------------------------- */

  let dpr = Math.min(
    window.devicePixelRatio || 1,
    2
  );

  function resizeCursorCanvas() {

    dpr = Math.min(
      window.devicePixelRatio || 1,
      2
    );

    canvas.width = innerWidth * dpr;
    canvas.height = innerHeight * dpr;

    canvas.style.width =
      innerWidth + 'px';

    canvas.style.height =
      innerHeight + 'px';

    ctx.setTransform(
      dpr,
      0,
      0,
      dpr,
      0,
      0
    );
  }

  resizeCursorCanvas();

  addEventListener(
    'resize',
    resizeCursorCanvas
  );


  /* -----------------------------------------
     POINTER STATE
     ----------------------------------------- */

  let targetX = -200;
  let targetY = -200;

  let mouseX = targetX;
  let mouseY = targetY;

  let previousX = targetX;
  let previousY = targetY;

  let velocity = 0;

  let visible = false;


  /* -----------------------------------------
     CIRCULAR PARTICLE TRAIL
     ----------------------------------------- */

  /*
   * Each object is one circle.
   *
   * The circles follow one another:
   *
   * cursor
   *   ↓
   * ● ● ● ● ● ● ● ● ●
   *
   * There is NO line connecting them.
   */

  const points = Array.from(
    { length: 18 },
    () => ({
      x: targetX,
      y: targetY
    })
  );


  /* -----------------------------------------
     POINTER MOVE
     ----------------------------------------- */

  addEventListener(
    'pointermove',
    e => {

      targetX = e.clientX;
      targetY = e.clientY;

      visible = true;

      c.classList.add('on');
      canvas.classList.add('on');


      /*
       * Cursor label.
       */
      const target =
        e.target.closest &&
        e.target.closest(
          'a,button,[data-cursor]'
        );

      const text =
        target
          ? (target.dataset.cursor || '')
          : '';

      l.textContent = text;

      l.classList.toggle(
        'on',
        !!text
      );
    }
  );


  /* -----------------------------------------
     POINTER LEAVES PAGE
     ----------------------------------------- */

  document.documentElement.addEventListener(
    'pointerleave',
    () => {

      visible = false;

      c.classList.remove('on');
      l.classList.remove('on');
      canvas.classList.remove('on');
    }
  );


  /* -----------------------------------------
     DRAW CURSOR
     ----------------------------------------- */

  function drawGlow() {

    /*
     * If the pointer isn't on the page,
     * clear the canvas.
     */
    if (!visible) {

      ctx.clearRect(
        0,
        0,
        innerWidth,
        innerHeight
      );

      requestAnimationFrame(drawGlow);

      return;
    }


    /* ---------------------------------------
       SMOOTH CURSOR MOVEMENT
       --------------------------------------- */

    const dx =
      targetX - mouseX;

    const dy =
      targetY - mouseY;

    mouseX += dx * 0.24;
    mouseY += dy * 0.24;


    /* ---------------------------------------
       MOVEMENT SPEED
       --------------------------------------- */

    const movementX =
      mouseX - previousX;

    const movementY =
      mouseY - previousY;

    const movement =
      Math.sqrt(
        movementX * movementX +
        movementY * movementY
      );

    velocity +=
      (movement - velocity) * 0.18;

    previousX = mouseX;
    previousY = mouseY;


    /* ---------------------------------------
       FIRST PARTICLE
       --------------------------------------- */

    points[0].x = mouseX;
    points[0].y = mouseY;


    /* ---------------------------------------
       PARTICLES FOLLOW EACH OTHER
       --------------------------------------- */

    for (
      let i = 1;
      i < points.length;
      i++
    ) {

      const current =
        points[i];

      const previous =
        points[i - 1];

      /*
       * This is the important part.
       *
       * Every circle follows the circle
       * directly in front of it.
       */
      const followX = 0.7;
      const followY = 0.7;

      current.x +=
        ((previous.x - current.x) *
        followX);

      current.y +=
        ((previous.y - current.y) *
        followY);
    }


    /* ---------------------------------------
       CLEAR CANVAS
       --------------------------------------- */

    ctx.clearRect(
      0,
      0,
      innerWidth,
      innerHeight
    );


    /* ---------------------------------------
       CIRCULAR GLOW PARTICLES
       --------------------------------------- */

    ctx.save();

    ctx.globalCompositeOperation =
      'screen';


    points.forEach((p, i) => {

      /*
       * 1 = cursor
       * 0 = end of trail
       */
      const progress =
        1 - i / points.length;


      /*
       * Main circle size.
       *
       * Bigger near cursor,
       * smaller toward the tail.
       */
      const radius =
        12 * progress + 3;


      /*
       * Fade toward the tail.
       */
      const opacity =
        0.60 *
        Math.pow(progress, 1.4);


      /* -------------------------------------
         OUTER GLOW
         ------------------------------------- */

      const glowRadius =
        radius*2;

      const glow =
        ctx.createRadialGradient(
          p.x,
          p.y,
          0,
          p.x,
          p.y,
          glowRadius
        );

      glow.addColorStop(
        0,
        `rgba(255, 240, 225, ${opacity})`
      );

      glow.addColorStop(
        0.25,
        `rgba(255, 220, 195, ${opacity * 0.55})`
      );

      glow.addColorStop(
        0.60,
        `rgba(255, 200, 175, ${opacity * 0.18})`
      );

      glow.addColorStop(
        1,
        'rgba(255, 190, 160, 0)'
      );


      /*
       * Draw circular glow.
       */
      ctx.beginPath();

      ctx.arc(
        p.x,
        p.y,
        glowRadius,
        0,
        Math.PI * 2
      );

      ctx.fillStyle = glow;

      ctx.filter =
        'blur(4px)';

      ctx.fill();


      /* -------------------------------------
         ACTUAL CIRCLE
         ------------------------------------- */

      ctx.filter = 'none';

      ctx.beginPath();

      ctx.arc(
        p.x,
        p.y,
        radius,
        0,
        Math.PI * 2
      );

      ctx.fillStyle =
        `rgba(255, 235, 220, ${opacity})`;

      ctx.fill();

    });

    ctx.restore();


    /* ---------------------------------------
       BRIGHT CURSOR CORE
       --------------------------------------- */

    const coreRadius =
      22 +
      Math.min(
        velocity * 1.4,
        20
      );

    const core =
      ctx.createRadialGradient(
        mouseX,
        mouseY,
        0,
        mouseX,
        mouseY,
        coreRadius
      );

    core.addColorStop(
      0,
      'rgba(255,255,250,0.90)',
      'opacity(0.5)'
    );

    core.addColorStop(
      0.18,
      'rgba(255,240,225,0.60)'
    );

    core.addColorStop(
      0.45,
      'rgba(255,218,190,0.25)'
    );

    core.addColorStop(
      1,
      'rgba(255,200,170,0)'
    );


    ctx.save();

    ctx.globalCompositeOperation =
      'screen';

    ctx.fillStyle = core;

    ctx.beginPath();

    ctx.arc(
      mouseX,
      mouseY,
      coreRadius,
      0,
      Math.PI * 2
    );

    ctx.fill();

    ctx.restore();


    /* ---------------------------------------
       CURSOR LABEL
       --------------------------------------- */

    l.style.left =
      mouseX + 'px';

    l.style.top =
      mouseY + 'px';


    requestAnimationFrame(
      drawGlow
    );
  }


  /* -----------------------------------------
     START
     ----------------------------------------- */

  drawGlow();

}
})();